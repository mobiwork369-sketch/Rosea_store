<?php
require_once __DIR__ . '/includes/bootstrap.php';
$q = trim($_GET['q'] ?? '');
$category = trim($_GET['category'] ?? '');
$categoryMap = [
    'cleansing'=>'پاک‌سازی و شوینده صورت','toner'=>'تونر و میست','hydration'=>'آبرسانی و مرطوب‌کننده',
    'brightening'=>'ضدلک و روشن‌کننده','antiaging'=>'ضدچروک و جوان‌سازی','special'=>'مراقبت تخصصی',
    'acne'=>'ضدجوش و کنترل چربی','sensitive'=>'پوست حساس و آرام‌بخش','protection'=>'محافظت و ضدآفتاب',
    'perfume'=>'عطر و ادکلن','home-fragrance'=>'خوشبوکننده‌ها'
];
$sql = "SELECT * FROM products WHERE is_active=1"; $args=[];
if ($q !== '') { $sql .= " AND (name LIKE ? OR description LIKE ?)"; $args[]="%$q%"; $args[]="%$q%"; }
if ($category === 'skincare') {
    $sql .= " AND category IN ('cleansing','toner','hydration','brightening','antiaging','special','acne','sensitive','protection')";
} elseif ($category !== '' && isset($categoryMap[$category])) {
    $sql .= " AND category=?"; $args[]=$category;
} elseif ($category !== '') {
    $category = '';
}
$sql .= " ORDER BY is_featured DESC,id DESC";
$st=$pdo->prepare($sql); $st->execute($args); $products=$st->fetchAll();
$pageTitle = $category && isset($categoryMap[$category]) ? $categoryMap[$category].' | فروشگاه رُزآرا' : 'فروشگاه محصولات رُزآرا';
$pageDescription = 'مشاهده و جستجوی محصولات مراقبت پوست، عطر و خوشبوکننده در فروشگاه رُزآرا.';
include __DIR__ . '/includes/header.php';
?>
<main class="page-content container">
<h1 class="page-title"><?=e($pageTitle)?></h1>
<nav class="filters" aria-label="دسته‌بندی محصولات">
<a href="products.php">همه محصولات</a><a href="?category=skincare">همه محصولات مراقبت پوست</a>
<?php foreach($categoryMap as $slug=>$label):?><a href="?category=<?=e($slug)?>"><?=e($label)?></a><?php endforeach;?>
</nav>
<?php if($q!==''):?><p>نتایج جستجو برای: <strong><?=e($q)?></strong></p><?php endif;?>
<div class="product-grid">
<?php foreach($products as $product):?>
<article class="product-card"><button class="wish" type="button" aria-label="افزودن به علاقه‌مندی‌ها">♡</button><a class="product-image" href="product.php?id=<?=(int)$product['id']?>"><img src="<?=e($product['image'])?>" alt="<?=e($product['name'])?>" loading="lazy"></a><div class="product-info"><a class="product-name" href="product.php?id=<?=(int)$product['id']?>"><?=e($product['name'])?></a><div class="rating">★★★★★ <small><?=e($product['rating'])?></small></div><strong class="price"><?=toman($product['price'])?></strong><button class="add-cart" data-id="<?=(int)$product['id']?>" data-name="<?=e($product['name'])?>" data-price="<?=(int)$product['price']?>" data-image="<?=e($product['image'])?>">افزودن به سبد خرید</button></div></article>
<?php endforeach;?>
<?php if(!$products):?><p class="empty-state">محصولی در این دسته‌بندی پیدا نشد. بعداً محصولات جدیدی به این بخش اضافه می‌شوند.</p><?php endif;?>
</div></main>
<?php include __DIR__ . '/includes/footer.php'; ?>
