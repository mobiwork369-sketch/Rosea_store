<?php
require_once __DIR__ . '/includes/bootstrap.php';
$products = $pdo->query("SELECT * FROM products WHERE is_active=1 ORDER BY is_featured DESC, id DESC LIMIT 10")->fetchAll();
$articles = $pdo->query("SELECT * FROM articles WHERE is_published=1 ORDER BY created_at DESC LIMIT 4")->fetchAll();
$reviews = $pdo->query("SELECT r.*, u.full_name FROM reviews r JOIN users u ON u.id=r.user_id WHERE r.is_approved=1 ORDER BY r.created_at DESC LIMIT 3")->fetchAll();
$pageTitle = 'رُزآرا | فروشگاه تخصصی مراقبت پوست، عطر و خوشبوکننده';
$pageDescription = 'خرید محصولات مراقبت پوست، سرم، آبرسان، ضدآفتاب، عطر و خوشبوکننده از فروشگاه رُزآرا؛ همراه با راهنمای انتخاب و مجله مراقبت پوست.';
include __DIR__ . '/includes/header.php';
?>
<main>
  <section class="hero" aria-label="پیشنهادهای ویژه رُزآرا" data-slider>
    <div class="hero-track">
      <article class="hero-slide is-active" data-slide="0" aria-hidden="false">
        <img class="hero-media" src="img/hero-rose.jpg" alt="تصویر کمپین اصلی رُزآرا با عطر، گل رز و محصولات مراقبت پوست" fetchpriority="high" width="1024" height="340">
        <div class="hero-shade"></div>
        <div class="hero-copy"><span class="eyebrow">زیبایی، از مراقبت آغاز می‌شود</span><h1>زیبایی، از جزئیات آغاز می‌شود</h1><p>انتخابی هوشمند برای مراقبت پوست و رایحه‌ای ماندگار</p><a class="btn btn-primary" href="products.php">مشاهده محصولات <span aria-hidden="true">←</span></a></div>
      </article>
      <article class="hero-slide" data-slide="1" aria-hidden="true" inert>
        <img class="hero-media" src="img/banner-slider-perfume.jpg" alt="چیدمان لوکس عطرهای رُزآرا در کنار گل‌های رز" loading="lazy" width="2048" height="768">
        <div class="hero-shade"></div>
        <div class="hero-copy"><span class="eyebrow">رایحه‌ای برای به‌یادماندن</span><h2>امضای تو، یک رایحه خاص</h2><p>دنیای عطرها و خوشبوکننده‌های منتخب را کشف کن</p><a class="btn btn-primary" href="products.php?category=perfume">مشاهده عطرها <span aria-hidden="true">←</span></a></div>
      </article>
      <article class="hero-slide" data-slide="2" aria-hidden="true" inert>
        <img class="hero-media" src="img/banner-slider-skincare.jpg" alt="محصولات سرم و کرم مراقبت پوست با گل رز" loading="lazy" width="1942" height="809">
        <div class="hero-shade"></div>
        <div class="hero-copy"><span class="eyebrow">روتین آگاهانه، پوستی شاداب</span><h2>مراقبت تخصصی از پوست</h2><p>از پاک‌سازی تا آبرسانی و محافظت روزانه</p><a class="btn btn-primary" href="products.php?category=skincare">کشف محصولات پوست <span aria-hidden="true">←</span></a></div>
      </article>
    </div>
    <button class="slider-arrow prev" type="button" aria-label="اسلاید قبلی">‹</button>
    <button class="slider-arrow next" type="button" aria-label="اسلاید بعدی">›</button>
    <div class="slider-controls" aria-label="انتخاب اسلاید">
      <button class="dot is-active" type="button" aria-label="نمایش اسلاید اول" aria-pressed="true"></button>
      <button class="dot" type="button" aria-label="نمایش اسلاید دوم" aria-pressed="false"></button>
      <button class="dot" type="button" aria-label="نمایش اسلاید سوم" aria-pressed="false"></button>
    </div>
    <button class="slider-pause" type="button" aria-label="توقف پخش خودکار اسلایدر" aria-pressed="false">Ⅱ</button>
  </section>

  <section class="category-strip container">
    <a class="category-card" href="products.php?category=perfume"><img src="img/category-perfume.jpg" alt="عطر و ادکلن"><span>عطر و ادکلن</span></a>
    <a class="category-card" href="products.php?category=home-fragrance"><img src="img/banner-homefragrance.jpg" alt="خوشبوکننده‌ها"><span>خوشبوکننده‌ها</span></a>
    <a class="category-card" href="products.php?category=protection"><img src="img/category-cleanse.jpg" alt="محافظت روزانه"><span>محافظت روزانه</span></a>
    <a class="category-card" href="products.php?category=brightening"><img src="img/category-serum.jpg" alt="ضدلک و روشن‌کننده"><span>ضدلک و روشن‌کننده</span></a>
    <a class="category-card" href="products.php?category=hydration"><img src="img/category-moisturizer.jpg" alt="آبرسانی"><span>آبرسانی و رطوبت</span></a>
    <a class="category-card" href="products.php?category=cleansing"><img src="img/banner-spa.jpg" alt="پاک‌سازی"><span>پاک‌سازی</span></a>
  </section>

  <section class="section container" id="products">
    <div class="section-heading"><span></span><h2>محصولات <b>منتخب</b> رُزآرا</h2><span></span></div>
    <div class="product-grid">
      <?php foreach($products as $p): ?>
      <article class="product-card">
        <button class="wish" aria-label="افزودن به علاقه‌مندی‌ها">♡</button>
        <a class="product-image" href="product.php?id=<?= (int)$p['id'] ?>"><img src="<?= e($p['image']) ?>" alt="<?= e($p['name']) ?>"></a>
        <div class="product-info"><a href="product.php?id=<?= (int)$p['id'] ?>" class="product-name"><?= e($p['name']) ?></a><div class="rating">★★★★★ <small><?= number_format((float)$p['rating'],1) ?></small></div><strong class="price"><?= toman($p['price']) ?></strong><button class="add-cart" data-id="<?= (int)$p['id'] ?>" data-name="<?= e($p['name']) ?>" data-price="<?= (int)$p['price'] ?>" data-image="<?= e($p['image']) ?>">افزودن به سبد خرید <b>＋</b></button></div>
      </article>
      <?php endforeach; ?>
      <?php if(!$products): ?><p class="empty-state">هنوز محصولی ثبت نشده است. پس از ورود به پنل مدیریت محصولات را اضافه کنید.</p><?php endif; ?>
    </div>
    <div class="center"><a class="btn btn-outline" href="products.php">مشاهده همه محصولات</a></div>
  </section>

  <section class="promo-grid container">
    <a class="promo promo-spa" href="products.php?category=skincare"><img src="img/banner-spa.jpg" alt=""><div><h3>روتین مراقبت پوست</h3><p>پوستی سالم و درخشان با انتخابی آگاهانه</p><span>مشاهده محصولات ←</span></div></a>
    <a class="promo promo-rose" href="products.php?category=perfume"><img src="img/banner-rose.jpg" alt=""><div><h3>رایحه‌ای برای ماندن</h3><p>عطرهایی ماندگار برای لحظه‌های خاص</p><span>مشاهده عطرها ←</span></div></a>
    <a class="promo promo-home" href="products.php?category=home-fragrance"><img src="img/banner-homefragrance.jpg" alt=""><div><h3>خوشبوکننده‌های خانه</h3><p>فضایی دلنشین و آرام</p><span>مشاهده بیشتر ←</span></div></a>
  </section>

  <section class="section container magazine">
    <div class="section-heading"><span></span><h2>مجله <b>رُزآرا</b></h2><span></span></div>
    <div class="article-grid">
      <?php foreach($articles as $a): ?>
      <a class="article-card" href="article.php?id=<?= (int)$a['id'] ?>"><img src="<?= e($a['image']) ?>" alt="<?= e($a['title']) ?>"><div><small>مجله مراقبت و زیبایی</small><h3><?= e($a['title']) ?></h3><span>مطالعه مقاله ←</span></div></a>
      <?php endforeach; ?>
      <?php if(!$articles): ?>
      <a class="article-card" href="article.php?demo=1"><img src="img/magazine-skincare.jpg" alt=""><div><small>راهنمای مراقبت</small><h3>چطور یک روتین ساده و مؤثر برای پوست بسازیم؟</h3><span>مطالعه مقاله ←</span></div></a>
      <a class="article-card" href="article.php?demo=2"><img src="img/magazine-perfume.jpg" alt=""><div><small>دنیای رایحه‌ها</small><h3>راهنمای انتخاب عطر متناسب با سلیقه شما</h3><span>مطالعه مقاله ←</span></div></a>
      <a class="article-card" href="article.php?demo=3"><img src="img/magazine-serum.jpg" alt=""><div><small>شناخت ترکیبات</small><h3>سرم‌های پوستی و روش استفاده از آن‌ها</h3><span>مطالعه مقاله ←</span></div></a>
      <a class="article-card" href="article.php?demo=4"><img src="img/magazine-flowers.jpg" alt=""><div><small>راهنمای خرید</small><h3>نکاتی برای انتخاب محصولات مراقبت پوست</h3><span>مطالعه مقاله ←</span></div></a>
      <?php endif; ?>
    </div>
  </section>

  <section class="reviews-section">
    <div class="container"><div class="section-heading light"><span></span><h2>دیدگاه <b>کاربران</b></h2><span></span></div>
      <div class="review-grid">
      <?php foreach($reviews as $r): ?><article class="review-card"><div class="review-stars"><?= str_repeat('★',(int)$r['rating']) ?></div><p><?= e($r['body']) ?></p><strong><?= e($r['full_name']) ?></strong></article><?php endforeach; ?>
      <?php if(!$reviews): ?><article class="review-card"><div class="review-stars">★★★★★</div><p>تجربه خریدی دلنشین، بسته‌بندی زیبا و محصولات باکیفیت. از خریدم رضایت دارم.</p><strong>مشتری رُزآرا</strong></article><article class="review-card"><div class="review-stars">★★★★★</div><p>توضیحات محصولات کامل بود و انتخاب برایم راحت‌تر شد.</p><strong>همراه رُزآرا</strong></article><article class="review-card"><div class="review-stars">★★★★☆</div><p>طراحی سایت زیباست و فرایند سفارش ساده و سریع انجام شد.</p><strong>کاربر رُزآرا</strong></article><?php endif; ?>
      </div><p class="review-note">برای ثبت دیدگاه، ابتدا وارد حساب کاربری خود شوید. مشاهده دیدگاه‌ها برای همه آزاد است.</p>
    </div>
  </section>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>
